export class Clients{
    name:String='';
    tickets:Number=0;
    email:String='';
    // movieName:String='';
}