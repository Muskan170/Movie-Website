export class Movies{
    id:number=0;
    description:String='';
    name:String='';
    price:String='';
    tickets:number=0;
    duration:String='';
    image:String='';
}