import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiMovieService } from 'src/app/services/api-movie.service';
import { UserService } from 'src/app/services/user.service';
import { Movies } from 'src/app/utilities/Movies';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  pop:Number=0;

  inputForm: FormGroup;

  user:any = {};
  
  constructor(private route:ActivatedRoute, private form:ApiMovieService, private userService : UserService,
    private fb : FormBuilder) { 
    this.inputForm=this.fb.group({
      name: new FormControl(null,[Validators.required,Validators.minLength(7)]),
      numberOfTickets : new FormControl(null,[Validators.required]),
      email: new FormControl(null,Validators.email),
    })
  }

  details:Movies[]=[];

  
  
  ngOnInit(): void {
    this.route.params.subscribe((param:any)=>{
      this.details.push(param);
    });
    console.log(this.details);
  }

  BookTicketListner(){
    this.pop=1;
  }

  CloseHandler(){
    this.pop=0;
  }

  formsubmitHandler(form:any){
    if(form.valid){
      console.log(form.value.name);
      console.log(form.value.numberOfTickets);
      this.user = Object.assign(this.user,this.inputForm.value);
      this.user['id']=this.details[0].id;
      this.user['meriMovie'] = this.details[0].name;
      this.user['remainingTicket'] = Number(this.details[0].tickets) - Number(form.value.numberOfTickets);
      //console.log(Number(this.user.tickets));
      console.log(typeof(this.user['remainingTicket']));
      this.userService.addUser(this.user);
      this.inputForm.reset();
      //this.details[0].tickets = this.user['remainingTicket'];

      let id=this.details[0].id;
      console.log("id = "+id);
      console.log(this.user['remainingTicket'])

      const updateexam=async()=>{
        let id=this.details[0].id;
        console.log("id = "+id);
        const data={
            description : this.details[0].description,
            duration : this.details[0].duration,
            image : this.details[0].image,
            name : this.details[0].name,
            price : this.details[0].price,
            tickets : this.user['remainingTicket']
        }
        let delurl=`https://633efee50dbc3309f3c2c114.mockapi.io/movies/${id}`;
        const response=await fetch(delurl,
         {method: "PUT",headers: {"Content-Type": "application/json", },
         body: JSON.stringify(data),});
        return await response.json();
        };

        updateexam().then((data)=>console.log(data)).catch();
        
    }
    else{
      alert("Kindly enter valid details")
    }
  }

  SeeDetailsListner(users:any){
    this.form.detailsTable(users);
  }
}
