import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiMovieService } from 'src/app/services/api-movie.service';
import { Movies } from 'src/app/utilities/Movies';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  movies:Movies[] = [];

  constructor(private service:ApiMovieService, private router : Router) { }

  ngOnInit(): void {
    this.getData();
  }

  getData(){
    this.service.getMovieDetails().subscribe((data:Movies[])=>{
      this.movies=data;
    })
  }

  getDetailsClick(movie:any){
    this.service.btnClickListner(movie);
  }

  searchText: string = '';

  onSearchTextEntered(searchValue:string){
    this.searchText = searchValue;
    //console.log(this.searchText);
  }

}
