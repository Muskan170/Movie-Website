import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { ApiMovieService } from 'src/app/services/api-movie.service';
import { UserService } from 'src/app/services/user.service';
import { Clients } from 'src/app/utilities/clients';
import { Movies } from 'src/app/utilities/Movies';
import {MatPaginator} from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { filter, Observable } from 'rxjs';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit,AfterViewInit {

  client:Clients[]=[];
  table:any=[]
  data1:any;
  localData:any;
  email:string='';
  index:number=0;
  remaining:number=0;
  currele:number=0;
  help:any;
  movies:any;
  data : any;
 
  displayedColumns: string[] = ['name', 'numberOfTickets','email','meriMovie','remainingTicket','edit'];
  
  dataSource : any;

  @ViewChild(MatPaginator,{static:false}) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    console.log('datasoource ',this.dataSource);
    this.dataSource.sort=this.sort;
  }

  applyFilter(event: any) {

    let s = (event.target as HTMLInputElement).value;
    this.dataSource.filter = s.trim().toLowerCase();
    console.log(this.table)
    let result = this.data.filter((val: { name: string; }) => val.name.toLowerCase().includes(s.toLowerCase()))
    this.dataSource = result
  }

  constructor(private service:ApiMovieService, private userService:UserService) { }

  ngOnInit(){
    this.getClientDetails();
    this.dataSource = new MatTableDataSource(this.table);
  }

  onEdit(item:any){
    item.isEdit = true;
  }

  onClose(user:any){
    
    user.isEdit = false
  }

  onSave(user:any){
    console.log("save ",user);
    localStorage.setItem("Users",JSON.stringify(this.table));
    var help = JSON.parse(localStorage.getItem("Users") || '{}');
    localStorage.setItem("Users",JSON.stringify(help));
    this.localData[this.index].numberOfTickets=this.currele;
    this.localData[this.index].remainingTicket=this.remaining;
    localStorage.setItem('Users',JSON.stringify(this.localData));

    this.updateAfterEdit(user,this.remaining);
    

    
  }

  updateAfterEdit(user:any,remain:any){
    //console.log("Inside update");
    //console.log(user);
    
    this.service.getMovieDetailsById(user.id).subscribe((data:any)=>{
      this.movies = data;
      //console.log(this.movies);
      const sentData={
        id:user.id,
        description:this.movies.description,
        name:this.movies.name,
        price:this.movies.price,
        tickets: remain,
        duration:this.movies.duration,
        image:this.movies.image
      }
      console.log(sentData);
      this.userService.updateMe(sentData,user.id).subscribe((data:Movies)=>{
        console.log("Data updated new = ",data);
        
      })
    })
  }

  UpdateTickets(){
    var tick = this.table[0].numberOfTickets;
    var l = JSON.parse(localStorage.getItem('Users') || '{}'); 
    
  }

  getClientDetails(){
    this.data = JSON.parse(localStorage.getItem('Users') || '{}')
    this.client.push(JSON.parse(localStorage.getItem('Users') || '{}'));
    console.log(this.client)
    this.table=this.client[0];
    console.log(this.table)
  this.dataSource=this.table 

  }
  

  fun(e:any)
  {
    this.currele=e;
     this.localData = JSON.parse(localStorage.getItem('Users') || '{}')
    const find = this.localData.some((element:any)=>{
      if(this.email === element.email){
        this.index = this.localData.indexOf(element);
      }
    })
    var user1Tickets = this.localData[this.index].numberOfTickets;
    console.log(user1Tickets," ",this.currele);
    if(user1Tickets != this.currele){
    this.remaining=Number(this.localData[this.index].remainingTicket) + Number(this.localData[this.index].numberOfTickets)-Number(this.currele);
    console.log("remaining tickets",this.remaining);
    }
  }

  emailFind(user:any){
     this.email=user.email;
  }
}
