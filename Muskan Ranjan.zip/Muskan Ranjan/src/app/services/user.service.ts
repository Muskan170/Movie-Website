import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { Constant } from '../utilities/constant';
import { Movies } from '../utilities/Movies';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  addUser(user:any){
    let users = [];
    if(localStorage.getItem('Users')){
      users = JSON.parse(localStorage.getItem('Users') || '{}');
      users = [user,...users];
    }
    else{
      users = [user];
    }
    localStorage.setItem('Users',JSON.stringify(users));
    console.log(users);
  }


  updateMe(val:any,id:any):Observable<any>{
    const h = new HttpHeaders();
    h.set('Content-Type','/application/json');
    console.log("after upadte data ",val);
    return this.http.put<Movies>(`${Constant.updateEndPoint}/${id}`,val)
    .pipe(retry(1),catchError(this.handleError));
  }

  handleError(err:any){
    return throwError(()=>{
      console.log(err);
    })
 
}
}
