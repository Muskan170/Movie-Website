import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { Movies } from '../utilities/Movies';
import { Constant } from '../utilities/constant';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ApiMovieService {

  constructor(private http : HttpClient, private router:Router) { }

  getMovieDetails():Observable<Movies[]>{
    return this.http.get<Movies[]>(Constant.getEndpoint.toString())
    .pipe(retry(1),catchError(this.handleError));
  }

  getMovieDetailsById(id:any):Observable<any>{
    return this.http.get<any>(`${Constant.updateEndPoint}/${id}`)
    .pipe(retry(1),catchError(this.handleError));
  }

  btnClickListner(movie:any){
    //console.log(movie);
    this.router.navigate(['/details',movie]);
  }

  detailsTable(users:any){
    this.router.navigate(['/users',users]);
  }

  handleError(err:any){
    return throwError(()=>{
      console.log(err);
    })
  }
}
