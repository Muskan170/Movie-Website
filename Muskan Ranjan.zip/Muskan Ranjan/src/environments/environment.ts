
export const environment = {
  baseURL : "https://633efee50dbc3309f3c2c114.mockapi.io/movies/",
  production: false
};
